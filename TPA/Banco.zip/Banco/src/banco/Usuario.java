/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Alunos
 */
public class Usuario {
    private String login;
    private String senha;
    private int idCliente;
    
    public Usuario(String login, String senha, int idCliente){
        this.login = login;
        this.senha = senha;
        this.idCliente = idCliente;
    }
    
    public String getLogin(){
        return this.login;
    }
    public void setLogin(String login){
        this.login = login;
    }
    public String getSenha(){
        return this.login;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    public int getIdCliente(){
        return this.idCliente;
    }
    public void setIdCliente(int IdCliente){
        this.idCliente = IdCliente;
    }
}
