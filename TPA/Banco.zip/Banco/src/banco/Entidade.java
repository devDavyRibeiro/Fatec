/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Alunos
 */
public class Entidade {
    private char nome;
    private String endereco;
    private char numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private char uf;
    private char cep;
    private char cnpj;
    
    public Entidade(char nome,String endereco, String complemento, char numero, String bairro,String cidade, char uf,char cep,char cnpj){
        this.nome = nome;
        this.endereco = endereco;
        this.complemento = complemento;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
        this.cep = cep;
        this.cnpj = cnpj;
    }
    
    public char getNome(){
        return this.nome;
    }
    public void setNome(char nome){
        this.nome = nome;
    }
    
    public String getEndereco(){
    return this.endereco;
    }
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    public String getComplemento(){
        return this.complemento;
    }
    public void setComplemento(String complemento){
        this.complemento = complemento;
    }

}
