/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Alunos
 */
public class Cliente extends Entidade{
    private int idCliente;
    private String email;
    private boolean status;
    private String fone;
    private char sexo;
    
    public Cliente (char nome,String endereco, String complemento, char numero,String bairro,String cidade,
            char uf,char cep,char cnpj,String email, boolean status, String fone, char sexo,int idCliente){
        super(nome, endereco, complemento, numero, bairro, cidade, uf, cep,cnpj);
        this.email = email;
        this.fone = fone;
        this.sexo = sexo;
        this.status = status;
        this.idCliente = idCliente;
    }
 
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
}
