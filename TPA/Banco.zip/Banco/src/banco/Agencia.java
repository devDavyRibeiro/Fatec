/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Alunos
 */
public class Agencia extends Entidade{
    private char numAgencia;
    private String gerente;
    
    public Agencia(char nome,String endereco, String complemento, char numero,
        String bairro,String cidade, char uf,char cep,char cnpj, char numAgencia, String gerente){
        super(nome, endereco, complemento, numero, bairro, cidade, uf, cep,cnpj);
        
        this.numAgencia = numAgencia;
        this.gerente = gerente;
    }
    public char getNumAgencia(){
        return this.numAgencia;
    }
    public void setNumAgencia(char numAgencia){
        this.numAgencia = numAgencia;
    }
}
