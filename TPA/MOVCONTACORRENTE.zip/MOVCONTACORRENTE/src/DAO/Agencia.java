/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import javax.swing.JOptionPane;

/**
 *
 * @author Alunos
 */
public class Agencia extends Entidade{
    private String numAgencia;
    private String gerente;
    private String fone;
    
    public Agencia(String nome,String endereco, String complemento, String numero,
        String bairro,String cidade, String uf,String cep,String cnpj, String numAgencia, String gerente){
        super(nome, endereco, complemento, numero, bairro, cidade, uf, cep,cnpj);
        
        this.numAgencia = numAgencia;
        this.gerente = gerente;
        this.fone = fone;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
    public Agencia(){
        //
    }
    public String getNumAgencia(){
        return this.numAgencia;
    }
    public void setNumAgencia(String numAgencia){
        if(validaNumAgencia(numAgencia)){
            this.numAgencia = numAgencia;
        }
    }

    public String getGerente() {
        return gerente;
    }

    public void setGerente(String gerente) {
        if(validaGerente(gerente)){
            this.gerente = gerente;
        }
  
    }
    public boolean validaNumAgencia(String numAgencia){
        if(numAgencia.isBlank() || numAgencia.isEmpty()){ //|| numAgencia.length() != 6
            JOptionPane.showMessageDialog(null, "Valor de Número Agência não pode ser em 0 ou nulo");
            return false;
        }
        else{
            return true;
        }
    }
    public boolean validaGerente(String gerente){
        if(gerente == null){
            JOptionPane.showMessageDialog(null, "Valor não pode ser em 0 ou nulo");
            return false;
        }
        else{
            return true;
        }
    }
    public String dadosSQLValues(){
        String dadosClientes;
        dadosClientes = "'"
                + this.getNumAgencia()+ "','"
                + this.getNome()+ "','"
                + this.getEndereco()+ "','"
                + this.getNumero()+ "','"
                + this.getComplemento()+ "','"
                + this.getBairro()+ "','"
                + this.getCidade()+ "','"
                + this.getUf()+ "','"
                + this.getCep()+ "','"
                + this.getFone()+ "'";
 
        return  dadosClientes;
    }

}
